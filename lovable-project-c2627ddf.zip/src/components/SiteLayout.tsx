import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const nav = [
  { to: "/observations", label: "Observations" },
  { to: "/articles", label: "Articles" },
  { to: "/videos", label: "Videos" },
  { to: "/vision", label: "Vision" },
  { to: "/membership", label: "Membership" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground font-body">
      <header className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-6 md:px-12">
        <Link to="/" className="font-display text-xl md:text-2xl tracking-tight">
          Indian Society For Scientific Consciousness
        </Link>
        <nav className="flex flex-wrap gap-5 text-sm">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="hover:opacity-60 transition-opacity" activeProps={{ className: "underline underline-offset-4" }}>
              {n.label}
            </Link>
          ))}
        </nav>
      </header>
      <main>{children}</main>
      <footer className="mt-24 border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-6 py-10 md:flex-row md:justify-between md:px-12">
          <span className="font-display text-lg">Indian Society For Scientific Consciousness</span>
          <a href="mailto:vy445617@hotmail.com" className="text-sm text-muted-foreground hover:text-foreground">vy445617@hotmail.com</a>
        </div>
      </footer>
    </div>
  );
}

export function PageHeader({ title, intro }: { title: string; intro: string }) {
  return (
    <section className="mx-auto max-w-7xl px-6 pt-16 pb-10 md:px-12">
      <h1 className="font-display text-5xl md:text-7xl italic tracking-tight">{title}</h1>
      <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{intro}</p>
    </section>
  );
}
