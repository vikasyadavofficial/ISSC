import { useState, type FormEvent } from "react";

const field = "w-full rounded-md border border-input bg-popover px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

export function JoinForm() {
  const [sent, setSent] = useState(false);
  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const body = `Name: ${f.get("first")} ${f.get("last")}\nEmail: ${f.get("email")}\nNewsletter: ${f.get("news") ? "yes" : "no"}\n\n${f.get("message")}`;
    window.location.href = `mailto:vy445617@hotmail.com?subject=${encodeURIComponent(String(f.get("subject")))}&body=${encodeURIComponent(body)}`;
    setSent(true);
  }
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="text-sm">First Name *<input name="first" required className={field} /></label>
        <label className="text-sm">Last Name *<input name="last" required className={field} /></label>
      </div>
      <label className="block text-sm">Email *<input name="email" type="email" required className={field} /></label>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="news" /> Sign up for news and updates</label>
      <label className="block text-sm">Subject *<input name="subject" required className={field} /></label>
      <label className="block text-sm">Message *<textarea name="message" required rows={5} className={field} /></label>
      <button type="submit" className="rounded-full bg-primary px-10 py-3 text-xs uppercase text-primary-foreground hover:opacity-85">Submit</button>
      {sent && <p className="text-sm text-muted-foreground">Thanks! Your email app should open to send the message.</p>}
    </form>
  );
}
