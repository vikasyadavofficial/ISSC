import lunar from "@/assets/fact-lunar-eclipse.jpg";

export type FactCheck = {
  date: string; // YYYY-MM-DD
  claim: string;
  verdict: "False" | "True" | "Misleading";
  image?: string;
  points: string[];
};

// Daily fact checks — add the newest at the top.
export const factChecks: FactCheck[] = [
  {
    date: "2026-10-25",
    claim: "Watching a lunar eclipse harms your eyes and brings bad fortune.",
    verdict: "False",
    image: lunar,
    points: [
      "A lunar eclipse happens when the Earth passes between the Sun and the Moon, and Earth's shadow falls on the Moon. It is a natural event that can be predicted years in advance.",
      "It is completely safe to watch a lunar eclipse with your naked eyes, binoculars or a telescope. The Moon only reflects sunlight, and during an eclipse it becomes even dimmer. (Only a solar eclipse needs special eye protection.)",
      "There is no scientific evidence that an eclipse brings bad luck, affects food, pregnancy or anyone's fortune. These are old beliefs from a time when people did not understand why the Moon turned red.",
      "The red colour of the eclipsed Moon comes from sunlight bending through Earth's atmosphere — the same reason sunsets look red.",
    ],
  },
];

export function formatDate(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}
