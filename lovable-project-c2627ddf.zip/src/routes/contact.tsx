import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout, PageHeader } from "@/components/SiteLayout";
import { JoinForm } from "@/components/JoinForm";
import { meta } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => meta("Contact — ISSC", "Write to us at vy445617@hotmail.com or send a message below."),
  component: () => (
    <SiteLayout>
      <PageHeader title="Contact" intro="Write to us at vy445617@hotmail.com or send a message below." />
      <section className="mx-auto max-w-7xl px-6 md:px-12"><div className="max-w-xl"><JoinForm /></div></section>
    </SiteLayout>
  ),
});
