import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { meta } from "@/lib/site";
import img from "@/assets/andromeda.webp";

export const Route = createFileRoute("/observations")({
  head: () => meta("Observing the Andromeda Galaxy — ISSC Observations", "Capturing the Andromeda Galaxy (M31) with a smartphone from a Bortle Class 9 sky in Bhiwadi, Rajasthan."),
  component: Observations,
});

const details = [
  ["Object", "Andromeda Galaxy (M31)"],
  ["Distance", "Approximately 2.5 million light-years"],
  ["Location", "Bhiwadi, Rajasthan, India"],
  ["Sky brightness", "Bortle Class 9 (as reported)"],
  ["Device", "Vivo T4x smartphone"],
  ["ISO", "200"],
  ["Shutter speed", "32 seconds"],
  ["Focus", "Infinity"],
  ["Image format", "RAW"],
  ["Frames stacked", "8"],
  ["Stacking software", "Siril"],
];

function Observations() {
  return (
    <SiteLayout>
      <section className="mx-auto grid max-w-7xl gap-12 px-6 py-20 md:grid-cols-2 md:px-12">
        <div className="space-y-5">
          <h1 className="text-4xl md:text-5xl font-semibold leading-tight tracking-tight">Observing the Andromeda Galaxy from a Bortle Class 9 Sky</h1>
          <p className="pt-4 font-bold">A small observation, a vast universe, and the power of scientific curiosity.</p>
          <p>The Andromeda Galaxy, located approximately 2.5 million light-years from Earth, is one of our nearest major galactic neighbours. Despite the severe light pollution of Bhiwadi, Rajasthan, I managed to capture this distant galaxy using my Vivo T4x smartphone.</p>
          <p>The image was captured at ISO 200 with a shutter speed of 32 seconds and focus set to infinity. I recorded the images in RAW format and stacked 8 frames using Siril to bring out the faint details of the galaxy.</p>
          <p>Capturing a galaxy from a Bortle Class 9 sky was a reminder that scientific exploration does not always require expensive equipment. It begins with curiosity, observation, experimentation, and the willingness to learn. By observing the night sky, we can question our understanding, explore the universe, and develop a deeper appreciation for science.</p>
          <p className="font-bold">Scientific temperament begins when we look beyond what we already know and ask what else we can discover.</p>
          <p className="italic">Observation details</p>
          <ul className="list-disc space-y-2 pl-10">
            {details.map(([k, v]) => (
              <li key={k}><strong>{k}:</strong> {v}</li>
            ))}
          </ul>
        </div>
        <img src={img} alt="Andromeda Galaxy (M31) and Mirach, plate-solved star field" className="w-full self-start md:mt-16" />
      </section>
    </SiteLayout>
  );
}
