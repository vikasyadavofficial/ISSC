import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { SiteLayout } from "@/components/SiteLayout";
import { meta } from "@/lib/site";

export const Route = createFileRoute("/membership")({
  head: () => meta("Membership — Join ISSC", "Become a member of the Indian Society for Scientific Consciousness and help promote scientific temperament."),
  component: Membership,
});

const field = "mt-1 w-full rounded-md border border-input bg-popover px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

function Membership() {
  const [sent, setSent] = useState(false);
  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const body = `Name: ${f.get("first")} ${f.get("last")}\nEmail: ${f.get("email")}\nNewsletter: ${f.get("news") ? "yes" : "no"}\nAge: ${f.get("age")}\nOccupation: ${f.get("occupation")}\n\nWhy I want to join:\n${f.get("why")}`;
    window.location.href = `mailto:vy445617@hotmail.com?subject=${encodeURIComponent("ISSC membership request")}&body=${encodeURIComponent(body)}`;
    setSent(true);
  }
  return (
    <SiteLayout>
      <section className="mx-auto grid max-w-7xl gap-16 px-6 py-20 md:grid-cols-2 md:px-12">
        <form onSubmit={onSubmit} className="space-y-4">
          <p className="text-sm">Name</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="text-sm">First Name (required)<input name="first" required className={field} /></label>
            <label className="text-sm">Last Name (required)<input name="last" required className={field} /></label>
          </div>
          <label className="block text-sm">Email (required)<input name="email" type="email" required className={field} /></label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="news" /> Sign up for news and updates</label>
          <label className="block text-sm">Why you want to join (required)<textarea name="why" required rows={4} className={field} /></label>
          <label className="block text-sm">Age (required)<input name="age" type="number" min={1} required className={field} /></label>
          <label className="block text-sm">Occupation (required)<input name="occupation" required className={field} /></label>
          <button type="submit" className="rounded-full bg-primary px-10 py-3 text-xs uppercase text-primary-foreground hover:opacity-85">Submit</button>
          {sent && <p className="text-sm text-muted-foreground">Thanks! Your email app should open to send your request.</p>}
        </form>
        <div className="space-y-6 md:pt-10">
          <h1 className="text-5xl md:text-6xl font-bold italic tracking-tight">Join Us</h1>
          <p>Become a part of the Indian Society for Scientific Consciousness (ISSC) and join us in promoting scientific temperament, rational thinking, and the spirit of questioning. Together, we can build a society that values science, evidence, and curiosity.</p>
          <p className="text-sm text-muted-foreground">After receiving and reviewing your information, we will send you an email confirming your membership.</p>
        </div>
      </section>
    </SiteLayout>
  );
}
