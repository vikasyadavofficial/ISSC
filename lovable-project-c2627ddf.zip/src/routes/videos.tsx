import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { meta } from "@/lib/site";

export const Route = createFileRoute("/videos")({
  head: () => meta("Videos — ISSC", "Short educational science videos from the Indian Society for Scientific Consciousness — coming soon."),
  component: () => (
    <SiteLayout>
      <section className="mx-auto flex min-h-[50vh] max-w-7xl items-center justify-center px-6">
        <h1 className="text-5xl md:text-7xl font-semibold tracking-tight">Coming soon</h1>
      </section>
    </SiteLayout>
  ),
});
