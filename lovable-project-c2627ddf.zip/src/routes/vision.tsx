import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { meta } from "@/lib/site";

export const Route = createFileRoute("/vision")({
  head: () => meta("Our Vision — ISSC", "Building a society that thinks, questions, and understands — scientific temper as a constitutional value."),
  component: Vision,
});

const stats = [
  ["44%", "of Indian adults said they believed astrology can influence life events."],
  ["49%", "said they believed in the evil eye, or harmful supernatural influence."],
  ["39%", "said magic, witchcraft, or sorcery can influence people's lives."],
  ["83%", "said they fixed important dates or times based on auspicious timings."],
];

const body = "space-y-5 text-sm font-semibold italic leading-relaxed";

function Vision() {
  return (
    <SiteLayout>
      <section className="mx-auto max-w-7xl px-6 py-20 md:px-12">
        <div className="grid max-w-3xl gap-x-12 gap-y-10 sm:grid-cols-2">
          {stats.map(([n, t]) => (
            <div key={n}>
              <p className="text-sm">{t}</p>
              <p className="mt-3 text-2xl">{n}</p>
            </div>
          ))}
        </div>
        <div className="mt-16 max-w-xl space-y-16 md:ml-[33%]">
          <div className="space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold italic leading-tight tracking-tight">Building a Society That Thinks, Questions, and Understands</h1>
            <div className={body}>
              <p>At the Indian Society for Scientific Consciousness (ISSC), our vision is to promote scientific temperament, develop respect for science, and encourage rational thinking in everyday life.</p>
              <p>We live in a world where education and technology are advancing rapidly, yet many people continue to accept beliefs and claims without examining the evidence behind them. We believe that the problem is not simply a lack of education, but also the lack of a habit of questioning, critical thinking, and scientific reasoning.</p>
              <p>We envision a society where curiosity is encouraged, questions are welcomed, and no idea is accepted merely because it has been passed down through generations or supported by authority. We want people to develop the confidence to ask why, seek evidence, test claims, and change their conclusions when new evidence emerges.</p>
            </div>
          </div>
          <div className="space-y-8">
            <h2 className="text-4xl md:text-5xl font-medium leading-tight tracking-tight">Scientific Temper Is a Constitutional Value</h2>
            <div className={body}>
              <p>The Constitution of India, under Article 51A(h), calls upon every citizen to develop scientific temper, humanism, and the spirit of inquiry and reform. At ISSC, we aim to put this vision into practice by encouraging curiosity, questioning unsupported beliefs, and promoting evidence-based thinking through articles, stories, videos, and experiments.</p>
            </div>
          </div>
          <div className="space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold italic leading-tight tracking-tight">How We Aim to Make a Difference</h2>
            <div className={body}>
              <p>Through engaging articles, thought-provoking stories, short educational videos, simple experiments, and careful observation, we aim to make science accessible and meaningful in everyday life.</p>
              <p>We strive to challenge superstition and pseudoscience through evidence and reasoning, promote open discussion, and inspire people to approach the world with curiosity rather than fear and inquiry rather than blind acceptance.</p>
              <p>Our ultimate goal is to contribute to a society that values reason, respects scientific knowledge, remains open to new evidence, and makes informed decisions for the betterment of humanity.</p>
              <p className="not-italic font-bold">Question everything. Seek evidence. Keep learning. Build a more rational society.</p>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
