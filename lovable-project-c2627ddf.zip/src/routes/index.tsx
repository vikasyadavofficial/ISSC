import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { JoinForm } from "@/components/JoinForm";
import { meta } from "@/lib/site";
import { factChecks, formatDate } from "@/lib/factchecks";
import logo from "@/assets/logo.webp";
import lab from "@/assets/lab.webp";
import vikas from "@/assets/vikas.webp";
import articles from "@/assets/articles.jpg";
import observe from "@/assets/observe.jpg";
import videos from "@/assets/videos.jpg";

export const Route = createFileRoute("/")({
  head: () => meta("Indian Society For Scientific Consciousness — Question Everything", "Promoting scientific temperament, rational thinking, and a society free from superstition."),
  component: Index,
});

const cards = [
  { img: articles, title: "Thorough articles", to: "/articles", text: "We share engaging articles and thought-provoking stories that explain scientific concepts, challenge superstitions, and inspire rational thinking." },
  { img: observe, title: "Observation and Experiments", to: "/observations", text: "We encourage people to explore the world through simple experiments and careful observation, helping them understand how science works through evidence, curiosity, and questioning." },
  { img: videos, title: "Videos", to: "/videos", text: "We make science easy and interesting through short educational videos that explore scientific ideas, everyday phenomena, and common misconceptions." },
] as const;

function Index() {
  return (
    <SiteLayout>
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-16 md:grid-cols-2 md:px-12">
        <div>
          <h1 className="text-5xl md:text-7xl font-bold italic leading-[1.02] tracking-tight">Indian Society For Scientific Consciousness</h1>
          <p className="mt-12 text-xl font-bold">Question Everything. Understand Scientifically.</p>
          <p className="mt-4 max-w-md text-sm font-semibold italic">Promoting scientific temperament, rational thinking, and a society free from superstition.</p>
          <a href="#what" className="mt-12 inline-flex rounded-full bg-primary px-14 py-4 text-sm uppercase text-primary-foreground hover:opacity-85">Explore now</a>
        </div>
        <img src={logo} alt="ISSC emblem" className="mx-auto w-72 md:w-80 rounded-full" />
      </section>

      <section id="what" className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-10 md:grid-cols-2 md:px-12">
        <img src={lab} alt="Scientist building an experiment" loading="lazy" className="w-full object-cover" />
        <div className="space-y-5">
          <h2 className="text-4xl font-bold">WHAT WE DO ?</h2>
          <p className="text-xl font-semibold">At the Indian Society for Scientific Consciousness (ISSC), we believe that a better society begins with curiosity, questioning, and rational thinking.</p>
          <p className="text-sm font-semibold italic">Our mission is to promote scientific temperament by making science and rationality accessible to everyone through engaging articles, thought-provoking stories, and short videos. We encourage people to question beliefs, examine evidence, challenge superstitions, and understand the world through logic and reason.</p>
          <p className="text-sm font-semibold italic">We believe that questioning is not a sign of disrespect but the first step towards understanding. By inspiring curiosity and critical thinking, we aim to build a society where people do not simply accept what they are told but learn to think, question, and discover for themselves.</p>
          <p className="text-sm font-bold">Our goal is simple: to replace blind belief with understanding, encourage questions over assumptions, and build a more scientific and rational society.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20 md:px-12">
        <h2 className="text-center text-4xl font-bold">How we Promote science</h2>
        <p className="mx-auto mt-4 max-w-2xl text-center text-muted-foreground">Promoting scientific temperament through engaging articles, thought-provoking stories, short videos, and the power of questioning.</p>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {cards.map((c) => (
            <div key={c.title} className="flex flex-col bg-card">
              <img src={c.img} alt={c.title} loading="lazy" width={944} height={704} className="aspect-[4/3] w-full object-cover" />
              <div className="flex flex-1 flex-col p-6">
                <h3 className="text-xl font-bold">{c.title}</h3>
                <p className="mt-3 flex-1 text-sm">{c.text}</p>
                <Link to={c.to} className="mt-6 self-start rounded-full bg-primary px-8 py-3 text-xs uppercase text-primary-foreground hover:opacity-85">Explore</Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-10 md:px-12">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <h2 className="text-3xl font-bold">Fact Check &amp; Scientific Thinking</h2>
          <p className="text-sm uppercase tracking-widest text-muted-foreground">Daily fact check</p>
        </div>
        {factChecks.map((f, idx) => (
          <article key={f.date + f.claim} className={`mt-6 grid gap-8 border-t border-border py-8 ${f.image && idx === 0 ? "md:grid-cols-2" : ""}`}>
            {f.image && idx === 0 && (
              <img src={f.image} alt={f.claim} loading="lazy" width={1200} height={800} className="w-full object-cover" />
            )}
            <div>
              <p className="text-sm text-muted-foreground">{formatDate(f.date)}{idx === 0 && " · Today's fact check"}</p>
              <p className="mt-3 text-sm font-semibold uppercase tracking-widest">Claim</p>
              <h3 className="mt-1 text-2xl font-bold leading-snug">“{f.claim}”</h3>
              <span className="mt-4 inline-block rounded-full bg-primary px-4 py-1 text-xs font-bold uppercase tracking-widest text-primary-foreground">Verdict: {f.verdict}</span>
              <ul className="mt-5 space-y-3 text-sm">
                {f.points.map((p) => <li key={p} className="border-l-2 border-foreground pl-4">{p}</li>)}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-2 md:px-12">
        <div>
          <h2 className="text-4xl font-bold">Join Us</h2>
          <div className="mt-8"><JoinForm /></div>
        </div>
        <div className="bg-card p-8">
          <p className="text-sm uppercase tracking-widest text-muted-foreground">Join me on Substack</p>
          <img src={vikas} alt="Vikas Yadav" loading="lazy" className="mt-4 w-40 object-cover" />
          <h3 className="mt-6 text-2xl font-bold">About Me — Vikas Yadav</h3>
          <div className="mt-4 space-y-3 text-sm">
            <p>Hi, I'm Vikas Yadav, a science enthusiast with a deep interest in astronomy, space exploration, and scientific thinking. I love exploring the universe, observing celestial objects, and understanding the science behind the world around us.</p>
            <p>I believe that questioning is the first step towards knowledge. Through my writing and observations, I aim to promote scientific temperament, encourage rational thinking, and challenge superstitions through logic and evidence.</p>
            <p>Join me on Substack as we explore the wonders of the universe, question what we believe, and develop a deeper understanding of the world through science.</p>
            <p className="font-bold">Stay curious. Keep questioning. Never stop exploring.</p>
          </div>
          <a href="https://vikasyadav0.substack.com/" target="_blank" rel="noreferrer" className="mt-6 inline-flex rounded-full bg-primary px-10 py-3 text-xs uppercase text-primary-foreground hover:opacity-85">Join</a>
        </div>
      </section>
    </SiteLayout>
  );
}
