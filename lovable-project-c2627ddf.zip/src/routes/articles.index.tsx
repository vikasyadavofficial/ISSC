import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { meta } from "@/lib/site";
import articles from "@/lib/articles.json";

export const Route = createFileRoute("/articles/")({
  head: () => meta("Articles — ISSC", "Articles on superstition, scientific temperament and the search for extraterrestrial life."),
  component: ArticlesList,
});

function ArticlesList() {
  return (
    <SiteLayout>
      <section className="mx-auto max-w-3xl px-6 py-20">
        {articles.map((a) => (
          <article key={a.slug} className="border-b border-border py-10 first:pt-0">
            <p className="text-sm text-muted-foreground">10/23/26</p>
            <h2 className="mt-2 text-3xl md:text-4xl font-semibold tracking-tight">
              <Link to="/articles/$slug" params={{ slug: a.slug }} className="hover:opacity-70">{a.title}</Link>
            </h2>
            <Link to="/articles/$slug" params={{ slug: a.slug }} className="mt-4 inline-block text-sm underline underline-offset-4">Read More</Link>
          </article>
        ))}
      </section>
    </SiteLayout>
  );
}
