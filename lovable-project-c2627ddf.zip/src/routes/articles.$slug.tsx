import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { meta } from "@/lib/site";
import articles from "@/lib/articles.json";

export const Route = createFileRoute("/articles/$slug")({
  loader: ({ params }) => {
    const i = articles.findIndex((a) => a.slug === params.slug);
    if (i < 0) throw notFound();
    return { a: articles[i]!, next: articles[(i + 1) % articles.length]! };
  },
  head: ({ loaderData }) =>
    loaderData ? meta(`${loaderData.a.title} — ISSC`, String(loaderData.a.blocks.find((b) => "p" in b)?.p ?? "").slice(0, 155)) : meta("Article — ISSC", "Article"),
  component: Article,
});

function Article() {
  const { a, next } = Route.useLoaderData();
  return (
    <SiteLayout>
      <article className="mx-auto max-w-3xl px-6 py-20">
        <Link to="/articles" className="text-sm underline underline-offset-4">← All articles</Link>
        <h1 className="mt-8 text-4xl md:text-5xl font-semibold leading-tight tracking-tight">{a.title}</h1>
        <p className="mt-4 text-sm text-muted-foreground">{a.date}</p>
        <div className="mt-10 space-y-5 leading-relaxed">
          {a.blocks.map((b, i) => ("h" in b ? <h2 key={i} className="pt-6 text-2xl font-bold">{b.h}</h2> : <p key={i}>{b.p}</p>))}
        </div>
        {next.slug !== a.slug && (
          <div className="mt-16 border-t border-border pt-8">
            <p className="text-sm text-muted-foreground">Next</p>
            <Link to="/articles/$slug" params={{ slug: next.slug }} className="text-xl font-semibold hover:opacity-70">{next.title}</Link>
          </div>
        )}
      </article>
    </SiteLayout>
  );
}
